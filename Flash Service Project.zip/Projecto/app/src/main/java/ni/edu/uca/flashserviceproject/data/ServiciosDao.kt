package ni.edu.uca.flashserviceproject.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ServiciosDao {

    @Query("SELECT * from servicios")
    fun getAll(): LiveData<List<Servicio>>

    @Query("SELECT * from servicios WHERE idServicio = :id")
    fun get(id: Int): LiveData<Servicio>

    @Insert
    fun insertAll (vararg servicios: Servicio)

    @Update
    fun update(servicio: Servicio)

    @Delete
    fun delete(servicio: Servicio)

}