package ni.edu.uca.flashserviceproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_recuperar_password.*

class RecuperarPassword : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recuperar_password)

        btn_enviar.setOnClickListener {
            val email: String = et_reset.text.toString().trim {
                it <= ' '
            }
            if (email.isEmpty()) {
                Toast.makeText(
                    this@RecuperarPassword,
                    "Por favor ingresa un correo válido",
                    Toast.LENGTH_SHORT
                ).show()

            } else {
                FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(
                                this@RecuperarPassword,
                                "Nueva contraseña enviada exitosamente",
                                Toast.LENGTH_LONG
                            ).show()

                            finish()
                        } else {
                            Toast.makeText(
                                this@RecuperarPassword,
                                task.exception!!.message.toString(),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
            }
        }
    }
}