package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_iniciar_sesion.*
import ni.edu.uca.flashserviceproject.data.DatabaseHelper


class IniciarSesion : AppCompatActivity() {

    lateinit var handler: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iniciar_sesion)

        handler = DatabaseHelper(this)

        val iniciar = findViewById<Button>(R.id.btn_iniciar)
        val atras = findViewById<Button>(R.id.btn_atras)


        iniciar.setOnClickListener {
            if (handler.userPresent(et_email.text.toString(), et_contraseña.text.toString())) {
                Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
                val intento2 = Intent(this, Carga::class.java)
                startActivity(intento2)
            } else {
                Toast.makeText(this, "Correo electronico o contraseña incorrecta", Toast.LENGTH_SHORT).show()
            }
        }

        atras.setOnClickListener {
            val intento2 = Intent (this, MainActivity::class.java)
            startActivity(intento2)
        }

        tv_recuperar.setOnClickListener {
            startActivity(Intent(this@IniciarSesion, RecuperarPassword::class.java))
        }
    }
}
