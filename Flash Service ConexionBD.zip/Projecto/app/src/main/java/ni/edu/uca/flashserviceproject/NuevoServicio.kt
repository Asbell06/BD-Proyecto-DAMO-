package ni.edu.uca.flashserviceproject
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_nuevo_servicio.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ni.edu.uca.flashserviceproject.data.AppDatabase
import ni.edu.uca.flashserviceproject.data.Servicio

class NuevoServicio: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nuevo_servicio)

        var idServicio: Int? = null

        if (intent.hasExtra("servicio")) {
            val servicio = intent.extras?.getSerializable("servicio") as Servicio

            et_nombre.setText(servicio.nombre)
            et_monto.setText(servicio.monto.toString())
            et_mes.setText(servicio.mes)
            et_fecha.setText(servicio.fecha)
            idServicio = servicio.idServicio
        }

        val database = AppDatabase.getDatabase(this)

        btn_save.setOnClickListener {
            val nombre = et_nombre.text.toString()
            val monto = et_monto.text.toString().toDouble()
            val mes = et_mes.text.toString()
            val fecha = et_fecha.text.toString()

            val servicio = Servicio(nombre, monto, mes, fecha)

            if(idServicio!= null){
                CoroutineScope(Dispatchers.IO).launch {
                    servicio.idServicio= idServicio
                    database.servicios().update(servicio)

                    this@NuevoServicio.finish()
                }
            }else{

            CoroutineScope(Dispatchers.IO).launch {
                database.servicios().insertAll(servicio)

                this@NuevoServicio.finish()
            }
            }
    }
    }
}