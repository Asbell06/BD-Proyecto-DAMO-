package ni.edu.uca.flashserviceproject.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/*Base de datos para el registro de los usuarios*/
class DatabaseHelper (context: Context):SQLiteOpenHelper(context, dbname, factory, version){
        override fun onCreate(p0: SQLiteDatabase?) {
            p0?.execSQL ("create table user (id integer primary key autoincrement," + "nombre varchar (45), email varchar (100), pwd varchar (30), fd varchar (9))")
        }

        override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
            TODO("Not yet implemented")
        }

        fun insertUserData (nombre: String, email:String, pwd:String, fd:String){
            val db: SQLiteDatabase = writableDatabase
            val values: ContentValues = ContentValues()
            values.put("nombre", nombre)
            values.put("email", email)
            values.put("pwd", pwd)
            values.put("fd", fd)

            db.insert("user", null, values)
            db.close()
        }

        fun userPresent (email:String, pwd:String):Boolean{
            val db = writableDatabase
            val query = "Select * from user where email = '$email' and pwd = '$pwd'"
            val cursor = db.rawQuery(query, null)
            if (cursor.count<=0){
                cursor.close()
                return false
            }
            cursor.close()
            return true
        }

        fun updateUserData (nombre: String, email:String, pwd:String, fd:String){
            val db: SQLiteDatabase = writableDatabase
            val values: ContentValues = ContentValues()
            values.put("nombre", nombre)
            values.put("email", email)
            values.put("pwd", pwd)
            values.put("fd", fd)

            db.update("user", values, "nombre = ?", arrayOf(nombre))
            db.close()
        }

        fun getUserData(nombre: String, email:String, pwd:String, fd:String): Boolean{
            val db: SQLiteDatabase = writableDatabase
            val query = "Select * from user"
            val cursor = db.rawQuery(query, null)
            if (cursor.count<=0){
                cursor.close()
                return false
            }
            cursor.close()
            return true
        }

        companion object{
            internal val dbname = "userDB"
            internal val factory = null
            internal val version = 1
        }
    }
